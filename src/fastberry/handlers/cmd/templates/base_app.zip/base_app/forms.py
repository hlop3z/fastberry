# -*- coding: utf-8 -*-
"""
    { Forms } for Operations
"""

import fastberry as fb

form = fb.input("form")

# Create your <forms> here.
