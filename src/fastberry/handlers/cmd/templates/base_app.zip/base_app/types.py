# -*- coding: utf-8 -*-
"""
    API - Fastberry Types
"""


import dataclasses as dc
import datetime
import decimal
import typing

import fastberry as fb

# Create your <types> here.
