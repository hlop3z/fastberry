# -*- coding: utf-8 -*-
"""
    { Types } for GraphQL
"""

from typing import Optional

import fastberry as fb

# Create your <types> here.
