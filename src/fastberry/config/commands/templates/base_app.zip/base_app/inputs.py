# -*- coding: utf-8 -*-
"""
    API - Complex Inputs
"""

import strawberry

# Create your <inputs> here.
