# -*- coding: utf-8 -*-
"""
    API - Strawberry CRUD
"""

# Import your <cruds> here.
from .demo import Demo
