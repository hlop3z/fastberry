# -*- coding: utf-8 -*-
"""API - Database Models"""

# Fastberry
from fastberry import Database

# Database Manager
model = Database()

# Create your <models> here.
