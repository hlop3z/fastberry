# -*- coding: utf-8 -*-
"""
    CRUD - Init
"""

# Import your <cruds> here.
from .demo import Demo
