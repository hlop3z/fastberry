# -*- coding: utf-8 -*-
"""
    API - Strawberry Types
"""


import dataclasses as dc
import datetime
import decimal
import typing

import fastberry

# Model
model = fastberry.Model()

# Create your <types> here.
