# -*- coding: utf-8 -*-
"""
    API - Strawberry Types
"""

# Strawberry
import strawberry

# Fastberry
from fastberry import BaseType

# Create your <types> here.
