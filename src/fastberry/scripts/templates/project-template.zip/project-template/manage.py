# -*- coding: utf-8 -*-
""" { Command-Line-Interface }
    Click's Main File.
"""
from fastberry.app import Controller

if __name__ == "__main__":
    # Mode: { CLI }
    Controller.cli()
