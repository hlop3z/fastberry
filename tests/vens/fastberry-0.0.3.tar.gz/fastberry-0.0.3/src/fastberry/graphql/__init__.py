"""
    Strawberry GraphQL Made Easy
"""

from .base import BaseType
