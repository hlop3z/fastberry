"""
    Project Settings Manager
"""

from .core import Settings
