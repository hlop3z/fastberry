import click

@click.command()
def cli():
    """Example script."""
    click.echo('Hello World!')